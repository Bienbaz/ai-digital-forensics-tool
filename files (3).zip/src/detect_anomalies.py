import joblib
from data_preprocessing import load_log_data, clean_and_extract_features

def detect_anomalies(df, model):
    """
    Use the trained model to flag anomalies in the log data.
    Adds an 'anomaly' column: -1 indicates anomaly, 1 indicates normal.
    """
    feature_cols = df.select_dtypes(include='number').columns
    if len(feature_cols) == 0:
        raise ValueError("No numeric features found for detection.")
    X = df[feature_cols].values
    anomalies = model.predict(X)
    df['anomaly'] = anomalies
    return df[df['anomaly'] == -1]

if __name__ == "__main__":
    import sys
    log_path = sys.argv[1]
    model_path = sys.argv[2]
    output_path = sys.argv[3]
    df = load_log_data(log_path)
    df_clean = clean_and_extract_features(df)
    model = joblib.load(model_path)
    suspicious = detect_anomalies(df_clean, model)
    suspicious.to_csv(output_path, index=False)
    print(f"Flagged entries saved to {output_path}")