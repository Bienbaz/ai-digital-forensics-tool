import pandas as pd
from sklearn.preprocessing import LabelEncoder

def load_log_data(filepath):
    """
    Load logs from a CSV file.
    """
    return pd.read_csv(filepath)

def clean_and_extract_features(df):
    """
    Clean log data and extract features appropriate for anomaly detection.

    - Converts timestamps to datetime
    - Encodes categorical features numerically
    - Handles missing values
    - Adds time-based features (e.g., hour)
    """
    df = df.copy()
    # Remove duplicates
    df = df.drop_duplicates()

    # Parse timestamp
    if 'timestamp' in df.columns:
        df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
        # Extract hour of day as a new feature
        df['hour'] = df['timestamp'].dt.hour.fillna(0).astype(int)

    # Fill missing numeric values with 0
    num_cols = df.select_dtypes(include='number').columns
    df[num_cols] = df[num_cols].fillna(0)

    # Encode categorical features
    cat_cols = ['source_ip', 'dest_ip', 'user', 'event_type', 'status']
    for col in cat_cols:
        if col in df.columns:
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col].astype(str))

    # Drop rows with all NaN values
    df = df.dropna(how='all')

    return df

if __name__ == "__main__":
    import sys
    df = load_log_data(sys.argv[1])
    df_clean = clean_and_extract_features(df)
    print(df_clean.head())