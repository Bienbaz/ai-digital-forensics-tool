import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import pandas as pd
import joblib
from data_preprocessing import clean_and_extract_features

def detect_anomalies_gui(df, model):
    feature_cols = df.select_dtypes(include='number').columns
    if len(feature_cols) == 0:
        raise ValueError("No numeric features found for detection.")
    X = df[feature_cols].values
    anomalies = model.predict(X)
    df['anomaly'] = anomalies
    return df[df['anomaly'] == -1]

class ForensicsGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("AI-Powered Digital Forensics Tool")
        self.log_path = None
        self.model_path = "models/anomaly_detector.pkl"
        self.df_anomalies = None

        # UI elements
        self.frame = ttk.Frame(root)
        self.frame.pack(padx=10, pady=10)

        self.upload_btn = ttk.Button(self.frame, text="Upload Log File", command=self.upload_file)
        self.upload_btn.grid(row=0, column=0, padx=5, pady=5)

        self.detect_btn = ttk.Button(self.frame, text="Detect Anomalies", command=self.detect_anomalies, state=tk.DISABLED)
        self.detect_btn.grid(row=0, column=1, padx=5, pady=5)

        self.export_btn = ttk.Button(self.frame, text="Export PDF Report", command=self.export_pdf, state=tk.DISABLED)
        self.export_btn.grid(row=0, column=2, padx=5, pady=5)

        self.tree = ttk.Treeview(self.frame, columns=("timestamp","source_ip","dest_ip","user","event_type","status","bytes_sent","bytes_received","hour","anomaly"), show="headings")
        for col in self.tree["columns"]:
            self.tree.heading(col, text=col)
        self.tree.grid(row=1, column=0, columnspan=3, sticky='nsew')

    def upload_file(self):
        file_path = filedialog.askopenfilename(title="Select Log CSV", filetypes=[("CSV Files", "*.csv")])
        if file_path:
            self.log_path = file_path
            self.detect_btn.config(state=tk.NORMAL)
            messagebox.showinfo("File Selected", f"Log file loaded:\n{file_path}")

    def detect_anomalies(self):
        try:
            df = pd.read_csv(self.log_path)
            df_clean = clean_and_extract_features(df)
            model = joblib.load(self.model_path)
            suspicious = detect_anomalies_gui(df_clean, model)
            self.df_anomalies = suspicious
            for i in self.tree.get_children():
                self.tree.delete(i)
            display_cols = self.tree["columns"]
            for _, row in suspicious.iterrows():
                self.tree.insert("", tk.END, values=tuple(row.get(col, "") for col in display_cols))
            self.export_btn.config(state=tk.NORMAL)
            messagebox.showinfo("Detection Complete", f"Suspicious entries found: {len(suspicious)}")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def export_pdf(self):
        from export_pdf import export_anomalies_to_pdf
        save_path = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF files", "*.pdf")],
            title="Save PDF Report"
        )
        if save_path and self.df_anomalies is not None:
            export_anomalies_to_pdf(self.df_anomalies, save_path)
            messagebox.showinfo("Export Complete", f"Report saved to {save_path}")

if __name__ == "__main__":
    root = tk.Tk()
    app = ForensicsGUI(root)
    root.mainloop()