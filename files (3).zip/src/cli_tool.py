import argparse

def main():
    parser = argparse.ArgumentParser(description="AI-Powered Log Anomaly Detector")
    parser.add_argument("--train", action="store_true", help="Train model on log data")
    parser.add_argument("--detect", action="store_true", help="Detect anomalies in new logs")
    parser.add_argument("--input", type=str, required=True, help="Path to input log CSV")
    parser.add_argument("--model", type=str, default="models/anomaly_detector.pkl", help="Path to model file")
    parser.add_argument("--output", type=str, default="outputs/suspicious_entries.csv", help="Path to output CSV")
    args = parser.parse_args()

    if args.train:
        from train_model import train_anomaly_detector
        from data_preprocessing import load_log_data, clean_and_extract_features
        import joblib
        df = load_log_data(args.input)
        df_clean = clean_and_extract_features(df)
        model = train_anomaly_detector(df_clean)
        joblib.dump(model, args.model)
        print(f"Model trained and saved to {args.model}")

    elif args.detect:
        from detect_anomalies import detect_anomalies
        from data_preprocessing import load_log_data, clean_and_extract_features
        import joblib
        df = load_log_data(args.input)
        df_clean = clean_and_extract_features(df)
        model = joblib.load(args.model)
        suspicious = detect_anomalies(df_clean, model)
        suspicious.to_csv(args.output, index=False)
        print(f"Suspicious entries saved to {args.output}")

if __name__ == "__main__":
    main()