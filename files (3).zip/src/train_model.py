import joblib
from data_preprocessing import load_log_data, clean_and_extract_features
from sklearn.ensemble import IsolationForest

def train_anomaly_detector(df):
    """
    Train an Isolation Forest model on the cleaned dataframe.
    Only uses numeric features.
    """
    # Select numeric features for unsupervised model
    feature_cols = df.select_dtypes(include='number').columns
    if len(feature_cols) == 0:
        raise ValueError("No numeric features found for training.")
    X = df[feature_cols].values
    model = IsolationForest(contamination=0.05, random_state=42)
    model.fit(X)
    return model

if __name__ == "__main__":
    import sys
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    df = load_log_data(input_path)
    df_clean = clean_and_extract_features(df)
    model = train_anomaly_detector(df_clean)
    joblib.dump(model, output_path)
    print(f"Model saved to {output_path}")